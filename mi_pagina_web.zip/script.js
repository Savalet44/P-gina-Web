document.addEventListener('DOMContentLoaded', () => {
    console.log('¡Bienvenido a tu página web personal!');
});
